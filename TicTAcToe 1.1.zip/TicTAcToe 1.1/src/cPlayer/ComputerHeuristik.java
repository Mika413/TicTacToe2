package cPlayer;

public class ComputerHeuristik extends ComputerPlayer{
    private int[][] preferredMoves;

    public ComputerHeuristik(PlayControl pc) {
        this.pc = pc;
    }

    public int draw() {

        return 0;
    }
}

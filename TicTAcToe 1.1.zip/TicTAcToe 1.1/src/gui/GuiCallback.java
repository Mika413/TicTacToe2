package gui;

public interface GuiCallback {
    void playerHasChosen(int nr);
}
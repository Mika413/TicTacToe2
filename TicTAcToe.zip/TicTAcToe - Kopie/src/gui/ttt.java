package gui;

import java.awt.EventQueue;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.Timer;

import cPlayer.ComputerPlayer;
import control.PlayControl;

public class ttt {

	
	private TTField fields;
	private PlayControl control;
	private ComputerPlayer player;
    private JFrame frame;
    private JPanel tttPanel;
    private JLabel label1;
    private JTextArea textArea;
    private Timer timer;
    private Random rand;
    private int winsForYou;
    private int winsForComputer;


	public ttt() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}


    private void createTTFields() {

    }

    private void disablePlayer() {

    }


    private void enablePlayer() {

    }


    private void startTimerForComputer() {

    }

 
    private boolean checkGameOver() {

        return false; 
    }


    private void computerShallPlay() {

    }


   


    public void playerHasChosen(int nr) {

    }



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ttt window = new ttt();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */


}

package cPlayer;

import control.PlayControl;

public class ComputerMinMax extends ComputerPlayer{
    private final int me = 0;
    private final int opp = 2;
    private final int eq = 1;
    private final int undef = -1;
    private int localMinX;
    private int localMinY;

    public ComputerMinMax(PlayControl pc) {
    	super(pc);
    }

    public int draw() {

        return 0;
    }

    private int evaluate() {
        return 0;
    }

    private int minimum() {
        return 0;
    }

    private int maximum() {
        return 0;
    }
}



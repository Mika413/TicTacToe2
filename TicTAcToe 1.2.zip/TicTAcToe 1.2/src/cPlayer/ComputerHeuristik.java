package cPlayer;

import control.PlayControl;

public class ComputerHeuristik extends ComputerPlayer{
    private int[][] preferredMoves;

    public ComputerHeuristik(PlayControl pc) {
    	  super(pc);
    }

    public int draw() {

        return 0;
    }
}
